# NOVI-DGP

This paper is accepted in TNNLS 2024.

Official code for NOVI-DGP: Neural Operator Variational Inference based on Regularized Stein Discrepancy for Deep Gaussian Processes.

Update: We have added a file named "dgp-novi-classification.ipynb" to reproduce our results on image classification of CIFAR10 using convolutional structure.
