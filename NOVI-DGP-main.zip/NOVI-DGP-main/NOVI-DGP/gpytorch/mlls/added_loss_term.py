#!/usr/bin/env python3


class AddedLossTerm(object):
    def loss(self):
        raise NotImplementedError
